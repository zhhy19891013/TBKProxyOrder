package com.yj.service;



/**
 * 
 * @author Administrator
 *
 */
public interface ISystemConfigService extends IBaseService{

	/**
	 * 查询cms配置
	 * @return
	 */
	public String searchSystemConfig();

	

}
