package com.yj.dao;

import com.yj.dao.impl.BaseDao;
/***
 * 系统设置默认比例配置
 * @author Administrator
 */
public class SystemCommonConfigDao extends BaseDao{

	public static final String SQL_NAME_UPDATE_SYSTEM_COMMON_CONFIG="updateSystemCommonConfig";
	public static final String SQL_NAME_SEARCH_SYSTEM_COMMON_CONFIG_BY_NAME="searchSystemCommonConfigByName";
	public static final String SQL_NAME_SEARCH_ALL_SYSTEM_COMMON_CONFIG="searchAllSystemCommonConfig";
	
}
