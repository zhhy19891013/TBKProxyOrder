package com.yj.dao;

import com.yj.dao.impl.BaseDao;
/**
 * 京东产品
 *
 */
public class JDBindDao extends BaseDao {
	public static final String updateBindMsg = "updateBindMsg";
	public static final String SEARCH_BIND = "searchBind";
	public static final String SEARCH_RECORD_BY_CONDITION_COUNT = "searchBindByConditionCount";
	public static final String SEARCH_RECORD_BY_CONDITION = "searchBindByCondition";
	public static final String DELETE_BY_ID = "deleteById"; 
	
	
}
