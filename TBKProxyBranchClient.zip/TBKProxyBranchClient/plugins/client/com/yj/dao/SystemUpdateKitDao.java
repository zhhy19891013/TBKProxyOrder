package com.yj.dao;
/**
 * 客戶端版本信息
 * @author tx
 */
public class SystemUpdateKitDao {

	public static final String SQL_NAME_ADD_SYSTEM_UPDATE_KIT = "addSystemUpdateKit";
	
	public static final String SQL_NAME_SEARCH_SYSTEM_UPDATE_KIT_BYVERSION = "searchSystemUpdateKitByVersion";
	
	public static final String SQL_NAME_SEARCH_SYSTEM_UPDATE_KIT_COUNT = "searchSystemUpdateKitCount";
	
	public static final String SQL_NAME_SEARCH_SYSTEM_UPDATE_KIT = "searchSystemUpdateKit";
	
	public static final String SQL_NAME_DELETE_SYSTEN_UPDATE_KIT = "deleteSystemUpdateKit";
	
	public static final String SQL_NAME_SEARCH_LAST_VERSION = "seacrhLastVersion";
	
	public static final String SQL_NAME_SEARCH_LAST_VERSION_NAME = "seacrhLastVersionName";
}
