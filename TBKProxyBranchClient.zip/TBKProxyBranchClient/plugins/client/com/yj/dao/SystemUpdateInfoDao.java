package com.yj.dao;
/**
 * 客戶端版本信息
 * @author zhhy
 */
public class SystemUpdateInfoDao {
	
	public static final String SQL_NAME_ADD_SYSTEM_UPDATE_INFO="addSystemUpdateInfo";
	public static final String SQL_NAME_SEARCH_SYSTEM_UPDATE_INFO_COUNT="searchSystemUpdateInfoCount";
	public static final String SQL_NAME_SEARCH_SYSTEM_UPDATE_INFO="searchSystemUpdateInfo";
	public static final String SQL_NAME_DELETE_SYSTEN_UPDATE_INFO="deleteSystemUpdateInfo";
	public static final String SQL_NAME_SEARCH_SYSTEM_UPDATE_INFO_BY_VERSION="searchSystemUpdateInfoByVersion";
	
}
