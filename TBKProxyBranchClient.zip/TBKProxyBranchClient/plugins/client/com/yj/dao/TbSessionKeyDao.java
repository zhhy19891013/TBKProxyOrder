package com.yj.dao;

public class TbSessionKeyDao {

	public static final String SQL_NAME_DELETE_SESSIONKEY_TBNAME = "deleteSessionkeyTbName";
	public static final String SQL_NAME_INSERT_SESSIONKEY_TBNAME = "insertSessionKeyTbName";
	
	public static final String SEARCH_SESSIONKEY_BY_TB_NAME="searchSessionKeyByTbName";
	
}
