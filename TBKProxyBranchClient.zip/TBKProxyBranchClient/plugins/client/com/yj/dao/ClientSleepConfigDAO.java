package com.yj.dao;

import com.yj.dao.impl.BaseDao;

public class ClientSleepConfigDAO extends BaseDao {

	public static final String SQL_NAME_SEARCH_SLEEP_CONFIG="searchSleepConfig";
	public static final String SQL_NAME_UPDATE_SLEEP_TIME = "updateSleepTime";
}
