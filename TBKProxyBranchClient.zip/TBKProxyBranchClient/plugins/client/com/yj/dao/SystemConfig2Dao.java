package com.yj.dao;

import com.yj.dao.impl.BaseDao;

public class SystemConfig2Dao extends BaseDao{
	
	public static final String SQL_NAME_UPDATE_SYSTEM_CONFIG2="updateSystemConfig2";
	public static final String SQL_NAME_SEARCH_SYSTEM_CONFIG2="searchSystemConfig2ByName";

}
