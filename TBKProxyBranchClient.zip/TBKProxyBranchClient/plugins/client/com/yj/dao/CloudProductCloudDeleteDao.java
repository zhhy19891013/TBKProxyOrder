package com.yj.dao;

import com.yj.dao.impl.BaseDao;

public class CloudProductCloudDeleteDao extends BaseDao {

	public static final String SQL_NAME_ADD_CLOUD_PRODUCT_DELETE="addCloudProductDelete";
	public static final String SQL_NAME_DELETE_CLOUD_PRODUCT_DELETE="deleteCloudProductDelete";
	public static final String SQL_NAME_SEARCH_CLOUD_PRODUCT_FOR_REFRESH="searchCloudProductForRefresh";
	
	
}
