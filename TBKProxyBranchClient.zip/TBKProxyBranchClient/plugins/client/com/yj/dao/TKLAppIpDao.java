package com.yj.dao;

import com.yj.dao.impl.BaseDao;

public class TKLAppIpDao extends BaseDao {
	//聚石塔ip
	public static final String SQL_NAME_SEARCH_TKL_APP_IP="searchMyTklIp";
	public static final String SQL_NAME_UPDATE_TKL_APP_IP="updateTklId";
	//app信息
	public static final String SQL_NAME_ADD_TKL_APP="addTklApp";
	public static final String SQL_NAME_DELETE_TKL_APP="deleteTklApp";
	public static final String SQL_NAME_UPDATE_TKL_APP="updateTklApp";
	public static final String SQL_NAME_SEARCH_TKL_APP="searchTklApp";
	public static final String SQL_NAME_SEARCH_TKL_APP_COUNT="searchTklAppCount";
	
	
}
