package com.yj.dao;

import com.yj.dao.impl.BaseDao;

public class CloudProductPlanDao extends BaseDao {

	public static final String SQL_NAME_ADD_CLOUD_PRODUCT_PLAN="addCloudProductPlan";
	public static final String SQL_NAME_DELETE_CLOUD_PRODUCT_PLAN="deleteCloudProductPlanByItemId";
	public static final String SQL_NAME_SEARCH_CLOUD_PRODUCT_PLAN="searchCloudProductPlan";
	public static final String SQL_NAME_SEARCH_CLOUD_PRODUCT_PLAN_CACHE="searchCloudProdcutPlanCache";
	public static final String SQL_NAME_SEARCH_CLOUD_PRODUCT_PLAN_CACHE2="searchCloudProdcutPlanCache2";
	
	
}
