package com.yj.util;

public class PrintUtil {
	
	
	
	
	public static void print(String s){
		System.out.println(s);
	}
	
	public static void print(int s){
		System.out.println(s + "");
	}

}
