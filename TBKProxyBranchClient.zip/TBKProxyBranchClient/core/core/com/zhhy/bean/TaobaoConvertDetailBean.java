package com.zhhy.bean;

public class TaobaoConvertDetailBean {
	private TaobaoConvertDetailResultBean result;

	public TaobaoConvertDetailResultBean getResult() {
		return result;
	}

	public void setResult(TaobaoConvertDetailResultBean result) {
		this.result = result;
	}
	
}
