package com.zhhy.bean;

import java.util.List;

public class LinkBean {
	private List<LinkBeanObject> urls;

	public List<LinkBeanObject> getUrls() {
		return urls;
	}

	public void setUrls(List<LinkBeanObject> urls) {
		this.urls = urls;
	}
	
}
