package com.zhhy.bean;

public class TaobaoConvertBean {
	private TaobaoConvertDetailBean tbk_privilege_get_response;

	public TaobaoConvertDetailBean getTbk_privilege_get_response() {
		return tbk_privilege_get_response;
	}

	public void setTbk_privilege_get_response(
			TaobaoConvertDetailBean tbk_privilege_get_response) {
		this.tbk_privilege_get_response = tbk_privilege_get_response;
	}
	
	
}
