package com.zhhy.bean;

public class LinkBeanObject {
	private String url_short;

	public String getUrl_short() {
		return url_short;
	}

	public void setUrl_short(String url_short) {
		this.url_short = url_short;
	}
	
}
