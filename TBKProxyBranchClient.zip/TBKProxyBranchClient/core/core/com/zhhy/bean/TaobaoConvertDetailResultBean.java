package com.zhhy.bean;

public class TaobaoConvertDetailResultBean {
	private TaobaoConvertDetailDataBean data;

	public TaobaoConvertDetailDataBean getData() {
		return data;
	}

	public void setData(TaobaoConvertDetailDataBean data) {
		this.data = data;
	}
	
}
