package com.yj.db.model;

import com.yj.db.model.reuse.BasicModel;

public class TKLAppIp extends BasicModel{
	private static final long serialVersionUID = 1L;

	private String ip;

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}
	
	
}
