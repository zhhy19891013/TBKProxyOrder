package com.yj.db.model;

/**
 * 小编推荐
 * 
 * @author Administrator
 */
public class CloudProductXbTj extends CloudProduct {
	private static final long serialVersionUID = 1L;
}
