package com.yj.db.model;

/**
 * 京东产品推送表格
 */
public class JDCloudProductSend extends JDCloudProduct {
	private static final long serialVersionUID = 1L;
	

}
